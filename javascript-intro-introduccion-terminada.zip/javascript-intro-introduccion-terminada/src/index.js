



console.log('Hola mundo')