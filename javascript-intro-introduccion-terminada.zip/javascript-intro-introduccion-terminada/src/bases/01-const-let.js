

const nombre   = 'Tony'
const apellido = 'Stark'


console.log( nombre, apellido )


if ( true ) {
    let nombre = '';
    nombre = 'Peter'
}


console.log(nombre)










